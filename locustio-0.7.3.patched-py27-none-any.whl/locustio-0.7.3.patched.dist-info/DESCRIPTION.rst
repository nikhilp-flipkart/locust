Locust is a python utility for doing easy, distributed load testing of a web site


